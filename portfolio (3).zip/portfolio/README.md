# Portfolio

A Flask-based personal portfolio site.

## Run locally

```bash
pip install -r requirements.txt
python app.py
```

Then open http://127.0.0.1:5000

## Edit content

Everything you'd want to change — your bio, skills, and the project list — lives
in `app.py` at the top, in the `PROFILE` dict and `PROJECTS` list. No template
edits needed for routine updates: add a new dict to `PROJECTS` and it
automatically gets a listing card and its own detail page at
`/projects/<slug>`.

Set `"featured": True` on a project to have it show on the home page.

## Structure

```
app.py                     routes + content
templates/
  base.html                shared shell + sidebar nav
  index.html                home page
  projects.html             full project list
  project_detail.html       single project page
  about.html                about page
  404.html
static/css/style.css       styling
```

## Deploying

This is a standard Flask app — it deploys as-is to Render, Railway, PythonAnywhere,
or any host that runs a WSGI app (e.g. with `gunicorn app:app`).
